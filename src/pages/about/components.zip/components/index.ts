export { default as Header } from "./header/Header";
export { default as ShortInfo } from "./shortInfo/ShortInfo";
export { default as Contact } from "./contact/Contact";
